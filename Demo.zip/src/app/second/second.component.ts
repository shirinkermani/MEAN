import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html'
  
})
export class SecondComponent 
{

  

}
