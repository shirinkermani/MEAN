import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appAppHighlight]'
})
export class AppHighlightDirective {

  constructor(  eleRef: ElementRef) {
    eleRef.nativeElement.style.background = 'red';
}

}
