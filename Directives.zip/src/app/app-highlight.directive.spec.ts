import { AppHighlightDirective } from './app-highlight.directive';

describe('AppHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new AppHighlightDirective();
    expect(directive).toBeTruthy();
  });
});
