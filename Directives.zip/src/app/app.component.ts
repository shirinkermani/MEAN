import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Directives';

  //ngFOR
  users: string[]=["John","Peter","Shirin"];

  countries:any[]=[
    {code:'ind',country:'India'},
    {code:'us',country:'United States'},
    {code:'uk',country:'United Kingdom'},
  ];

//ngIF
  isUserLoggedIn:boolean=true; 

 //ngSwitch
  inpvalue: number = 2; 
  showElement:any


  
}
