import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent  {
  num=2;
  str="My naMe Is ShIrIn KerMAni";
  res;
  ans;

  constructor(private _numberservice:NumberService,private _stringservice:StringService) 
  { 
    this.res=this._numberservice.ChkPrime(this.num);
    this.ans=this._stringservice.CountCapital(this.str);
  }

  ChkPrime()
  {
    this.res=this._numberservice.ChkPrime(this.num);
  }
  
  CountCapital()
  {
    this.ans=this._stringservice.CountCapital(this.str);
  }


  

}
