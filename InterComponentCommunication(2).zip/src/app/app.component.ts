import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment8-1';

   @Output() public Myevent = new EventEmitter();
  
  public Message=""

  public event()
  {
     this.Myevent.emit(this.Message);
     
  }
}
