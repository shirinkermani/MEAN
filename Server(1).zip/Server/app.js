express = require('express');
mongoose = require('mongoose');
bodyParser = require('body-parser')
batchesRoutes = require('./routes/batchesRoutes');

eobj=express();

eobj.use(batchesRoutes);

eobj.listen(4000,(request,response)=>{
    console.log("Marvellous Server Started succesfully at port 4000..")
});

eobj.get('/',(request,response)=>{
    response.send("Welocome to Marvellous Mean application");
});

Databasepath='mongodb+srv://marvellous:marvellous@batches.6r4pw.mongodb.net/?retryWrites=true&w=majority';

mongoose.connect(Databasepath).then(()=>{
    console.log("Database connection is succesfull");
}).catch((err)=>{
    console.log("Error in the database connection");
});