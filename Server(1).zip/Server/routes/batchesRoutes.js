express=require('express');

batchesModel=require('../models/batches.js');

eobj=express();
eobj.use(bodyParser.urlencoded({extended:false}))
eobj.use(bodyParser.json())

//Read the data from db
eobj.get('/batches',async(request,response)=>{
   batches=await batchesModel.find({}); //select*from_________; (sql query)
   try{
    response.send(batches);
   }
   catch(error)
   {
    response.status(500).send(error);
   }
});

//insert the data into db
eobj.post('/batches',async(request,response)=>{
    batches=new batchesModel(request.body);
    try{
        await batches.save(); //insert into batches values("PPA",3);
        response.send(batches);
        
    }
    catch(error)
        {
           response.status(500).send(error); 
        }
    
});

eobj.delete("/batches/:id",async(request,response)=>{
    try{
       batches=await batchesModel.findByIdAndDelete(request.params.id);
       if(!batches){
        response.status(404).send("There is no such batch");
       }
    }
    catch(error)
    {
       response.status(500).send(error);
    }
});


//update db

eobj.patch("/batches/:id",async(request,response)=>{
    try{
        await batchesModel.findByIdAndUpdate(request.params.id,request.body);
        await batchesModel.save();

    }
    catch(err)
    {
        response.status(500).send("failure in update");
    }
})

module.exports=eobj;


//CRUD application:

//C -> Create
//Endpoint:post
//Mongodb function:save()
//insert into tablename;


//R -> Read
//Endpoint:get
//Mongodb function:find()
//select *from tablename

//U -> Update
//Endpoint:patch
//Mongodb function:findByIdAndUpdate
//update tablename set duration= ____ where id=____;

//D -> Delete
//Endpoint:delete
//Mongodb function:findByIdAndDelete
//delete from tablename where id=_____;