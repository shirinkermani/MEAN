import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarvellovousComponent } from './marvellovous.component';

describe('MarvellovousComponent', () => {
  let component: MarvellovousComponent;
  let fixture: ComponentFixture<MarvellovousComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MarvellovousComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MarvellovousComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
