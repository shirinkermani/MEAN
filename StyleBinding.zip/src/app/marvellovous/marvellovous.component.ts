import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellovous',
  templateUrl: './marvellovous.component.html',
  styleUrls: ['./marvellovous.component.css']
})
export class MarvellovousComponent  {

  public Mycolor="orange";
  public Veg=true;


}
