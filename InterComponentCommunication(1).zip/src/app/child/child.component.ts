import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent  
{
  @Output() public Myevent=new EventEmitter();
  public Message=" Hello From Child.. ";


  public SendMessage()
{
  this.Myevent.emit(this.Message);
}
  

}
