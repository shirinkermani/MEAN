import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BatchDetailsComponent } from './batch-details/batch-details.component';
import { BatchesListComponent } from './batches-list/batches-list.component';
import { BatchServiceService } from './batch-service.service';
@NgModule({
  declarations: [
    AppComponent,
    BatchDetailsComponent,
    BatchesListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [BatchServiceService], // Register name of our service
  bootstrap: [AppComponent]
})
export class AppModule { }


/*
  Service - It is class with specific purpose.
  We can use service to share data between components
  and to implement application logic, External interaction 
  like database connections. 
*/