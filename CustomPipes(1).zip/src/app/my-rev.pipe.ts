import { Pipe, PipeTransform } from '@angular/core';



@Pipe({
  name: 'myRev'
})


export class MyRevPipe implements PipeTransform {
  Name:string | undefined;
  transform(value: any, ..._args: any[]): any {

    this.Name = value.split('').reverse().join('');
  
      return this.Name;
  
    }
}

