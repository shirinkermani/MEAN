
import { MyRevPipe } from './my-rev.pipe';

describe('MyRevPipe', () => {
  let pipe = new MyRevPipe();
    
    it('check the pipe', () => {
      
      expect(pipe.transform('abc')).toEqual('cba');
    });
  
  it('create an instance', () => {
    const pipe = new MyRevPipe();
    expect(pipe).toBeTruthy();
  });
});
