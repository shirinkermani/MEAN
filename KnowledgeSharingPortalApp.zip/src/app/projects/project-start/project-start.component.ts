import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-start',
  templateUrl: './project-start.component.html'
})
export class ProjectStartComponent
{
}
