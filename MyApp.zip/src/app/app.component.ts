import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template: ` 
  //       <h1> Welcome </h1>
  //       <h2> Course Name: {{ courseName }}</h2>
  //   `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  courseName = "Angular";

  changeName() {
    this.courseName = "TypeScript";
}

courses: any[] = [
  { id: 1, name: 'TypeScript' },
  { id: 2, name: 'Angular' },
  { id: 3, name: 'Node JS' },
  { id: 1, name: 'TypeScript' }
];

isAuthenticated!: boolean;
  submitted = false;
  userName!: string;
  onSubmit(name: string, password: string) {
    this.submitted = true;
    this.userName = name;
    if (name === 'admin' && password === 'admin') {
      this.isAuthenticated = true;
    } else {
      this.isAuthenticated = false;
    }
  }

  choice = 0;
  nextChoice() {
    this.choice++;
  }
}
