import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  admin=[]

  loginUserData={email:'',password:''};
  //email: any;
  //password: any;
  //_auth: any;
  //_router: any;
  //private _auth: any;
  //private _router: any;
  

  constructor( private _auth: AuthService,
               private _router: Router) { }

  ngOnInit(): void {
  }

  loginAdmin () 
  {
    this._auth.loginAdmin(this.loginUserData)
    .subscribe(
      (      res: { token: string; }) => {
        localStorage.setItem('token', res.token);
        this._router.navigate(['/admin']);
      },
      (      error: any) => {
        console.log(error)
      }
    ) ;
  }

}
