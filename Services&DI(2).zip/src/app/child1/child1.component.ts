import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component  {

  num=2;
  res;
  constructor(private _numberservice:NumberService)
   
  { 
    this.res=this._numberservice.ChkPrime(this.num);
  }

  ChkPrime()
  {
    this.res=this._numberservice.ChkPrime(this.num);
  }
  

}
