import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-componet',
  templateUrl: './image-componet.component.html',
  styleUrls: ['./image-componet.component.css']
})
export class ImageComponetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
