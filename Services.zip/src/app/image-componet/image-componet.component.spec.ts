import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageComponetComponent } from './image-componet.component';

describe('ImageComponetComponent', () => {
  let component: ImageComponetComponent;
  let fixture: ComponentFixture<ImageComponetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImageComponetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageComponetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
