import { Component, OnInit } from '@angular/core';
import { filter, Observable } from 'rxjs';

@Component({
  selector: 'app-text-comoponent',
  templateUrl: './text-comoponent.component.html',
  styleUrls: ['./text-comoponent.component.css']
})
export class TextComoponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    //promise
    const promise = new Promise(resolve=>{
    //1) console.log('Promise call...')
      setTimeout(()=>{
       resolve('Promise working')
      //2)  resolve('Promise working1')
      // 2) resolve('Promise working2')
      },1000)
    })

    //listen
    promise.then(result=>console.log(result));

    //observable
    const observable = new Observable(subscribe=>{
      //1)console.log('Observable call...')
      setTimeout(()=>{
        subscribe.next('Observable is working')
        //2) subscribe.next('Observable is working1')
        //2) subscribe.next('Observable is working2')
        //3) subscribe.next('Observable is working3')
       },1000)

    })

    //listen
     observable.subscribe(result=>console.log(result));

    // 3) observable.pipe(
    //    filter(d=>d==='Observable is working3')
    //  ).subscribe(result=>console.log(result));
  }

}
