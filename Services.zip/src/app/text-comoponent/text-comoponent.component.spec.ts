import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TextComoponentComponent } from './text-comoponent.component';

describe('TextComoponentComponent', () => {
  let component: TextComoponentComponent;
  let fixture: ComponentFixture<TextComoponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TextComoponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TextComoponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
