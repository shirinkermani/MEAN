import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TextComoponentComponent } from './text-comoponent/text-comoponent.component';
import { ImageComponetComponent } from './image-componet/image-componet.component';
import { UsersService } from './users.service';

@NgModule({
  declarations: [
    AppComponent,
    TextComoponentComponent,
    ImageComponetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [UsersService],
  bootstrap: [AppComponent]
})
export class AppModule { }
