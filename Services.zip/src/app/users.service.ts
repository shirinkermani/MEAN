import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor() { }

  getAllUsers(){
    return [
      {id:1, name:'Shirin', city:'Pune', salary:10000},
      {id:2, name:'Tanisha', city:'Nashik', salary:20000},
      {id:3, name:'Prass', city:'Mumbai', salary:30000},
      {id:4, name:'Hritik', city:'Indore', salary:40000}
    ];
  }
}
