import { Component,OnInit } from '@angular/core';
import { UsersService } from './users.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  pageTitle:string = 'Services in Angular';
  users:any[] | undefined;

  //dependency injection used to access the data from user service
  constructor(private userService:UsersService){

  }
  //it is used for intialization and here it is receiving the data from user service and storing it in a class level varaible this.users
  ngOnInit(){
    this.users=this.userService.getAllUsers();
  }

  

}
