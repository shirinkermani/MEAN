const { response } = require('express'); //function-handler
const express = require('express');

const app = express();



app.get('',Start);

function Start(request,response)
{
    response.send("Marvellous server has started");
}


app.get('/start',MarvellousRoot);
function MarvellousRoot(request,response)
{
    response.json({
        "Status":"Success"
    });
}


app.listen(3000, Marvellous); //here marvellous method is called


function Marvellous(request, response) 
{
    console.log("Marvellous Server is started...");

}

app.get('/getBatches',MarvellousBatches);

function MarvellousBatches(request, response)
{
    response.json({
        "BatchName" : "Python",
        "Fees" : 12500
    });
}

app.get('/getAdminDetails', MarvellousAdmin);

function MarvellousAdmin(request, response)
{
    response.json(
        {
            "Mobile" : "7020713938",
            "Mail" : "Admin@marvellousinforsystems.com"
        }
    )
}

app.get('/Demo', (request, response) => {
    response.json({
        "Data" : "Marvellous"
    });
});