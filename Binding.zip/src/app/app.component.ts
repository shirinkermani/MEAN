import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  public str="Marvellous Infosystems";
   
     Fun()
    {
      
      this.str="Educating For Better Tommorow";
      
    
    }
     
    public uc="";
    Sun()
    {
          this.uc="Marvellous Infosystems";
          
    }
 
    public lc="";
    Gun()
    {
      this.lc="marvellous infosystems";
    }

}
