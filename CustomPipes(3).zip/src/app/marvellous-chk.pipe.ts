import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform {

  transform(value: number, ...Param: string[]): string
{
  if(value%2 == 0)         
  return "isEven";      
return "isOdd";  
}
}