import { MarvellousChkPipe } from './marvellous-chk.pipe';

describe('MarvellousChkPipe', () => {
  

  it('should be even', () => {
    const pipe = new MarvellousChkPipe();
    expect(pipe.transform(4,'2')).toBe("isEven")
});

it('should be odd', () => {
  const pipe = new MarvellousChkPipe();
  expect(pipe.transform(7,'2')).toBe("isOdd")
});
});

