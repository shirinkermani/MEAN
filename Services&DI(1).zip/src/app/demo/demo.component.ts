import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent  {

   num1=10;
   num2=20;
   sum; Ans;
    
    

  constructor(private _arithmeticservice:ArithmeticService)
   { 
    this.sum = this._arithmeticservice.Add(this.num1, this.num2);
    this.Ans = this._arithmeticservice.Sub(this.num1, this.num2);
   }

  Add()
  {
    this.sum=this._arithmeticservice.Add(this.num1,this.num2);
    
  }

  Sub()
  {
    this.Ans=this._arithmeticservice.Sub(this.num1,this.num2);
    
  }

}
