import { Component } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ReactiveForms';
  firstname:any

   
  contactForm = new FormGroup({ //we have created an instance of a FormGroup and named it as contactForm
    firstname: new FormControl('shirin'), //These are the child control to the contact form
    lastname: new FormControl(),
    email: new FormControl(),
    gender: new FormControl(),
    isMarried: new FormControl(),
    country: new FormControl()
  })

  onSubmit() { //receive the form data in the component class
    console.log(this.contactForm.value); //send the value of our form data to the console window.
  }
   
}
