import { async, TestBed } from '@angular/core/testing';
import { MyAddPipe } from './my-add.pipe';

describe('MyAddPipe', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MyAddPipe
      ],
    }).compileComponents();
  }));
  it('should add 2 numbers', () => {
    const pipe = new MyAddPipe();
    expect(pipe.transform(7,'3')).toBe(10);
    
    // let obj = new MyMultPipe();
    // obj.transform(4,'3');
    // expect(obj.sum).toEqual(12);
  });
});

