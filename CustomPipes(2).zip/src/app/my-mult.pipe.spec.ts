import { async, TestBed} from '@angular/core/testing';
import { MyMultPipe } from './my-mult.pipe';

describe('MyMultPipe', () => {
  
  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MyMultPipe
      ],
    }).compileComponents();
  }));
  
  it('should multiply 2 numbers', () => {
    const pipe = new MyMultPipe();
    expect(pipe.transform(4,'3')).toBe(12);
    
    // let obj = new MyMultPipe();
    // obj.transform(4,'3');
    // expect(obj.sum).toEqual(12);
  });
});

