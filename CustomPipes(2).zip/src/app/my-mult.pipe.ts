import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myMult'
})
export class MyMultPipe implements PipeTransform {
 // sum: any;
sum=0;
  transform(value: number, ...args: string[]): number
  {
    let sum = value * 3;
    return sum
  }

}
