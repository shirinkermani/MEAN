import { Component } from '@angular/core';
import { ClientserviceService } from './clientservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Client';

  constructor(private service : ClientserviceService)
  {}

  ngOnInit()
  {
    this.getBathesfromAPI()
  }

  getBathesfromAPI()
  {
       this.service.getBatches().subscribe((Response)=>{
      console.log("Data from server : ",Response);
    });
  }
}
