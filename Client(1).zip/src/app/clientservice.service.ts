import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClientserviceService {

  constructor(private http : HttpClient) { }

  getBatches()
  {
    return this.http.get('/app/getBatches');
  }
}
