import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DataBinding';

  tip='Learning Points' //string interpolation
  getName(){
    return this.tip;
  }

  obj={         //string interpolation
    name:"John" , age:20
  }

   btnStatus:boolean=true; //PB

   changeTitle(){
     this.title=" Angular Data Binding"; //EB
   }

   username:string[]=[] //2waydb
}
