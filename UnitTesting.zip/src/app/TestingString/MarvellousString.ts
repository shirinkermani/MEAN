
export function Display(student: string)
{
    return student + ' welcome to Marvellous Infosystems'
}