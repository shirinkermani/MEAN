import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(public fbobj:FormBuilder)
  {}

  MarvellousForm=this.fbobj.group(
    {
      username :['', Validators.required],
      lastname :['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone : ['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      passowrd : ['',Validators.required],
      address :  ['',Validators.required],
      
    }
  );
}
